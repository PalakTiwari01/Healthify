package com.example.kushagra.finalshms;

public interface StepListener {
    public void step(long timeNs);
}
