package com.example.kushagra.finalshms;

public class User {
    private Integer Heightt;
    private Integer Weightt;
    private Integer Calorie;
    private Integer Step;

    public User() {
    }

    public Integer getHeightt() {
        return Heightt;
    }

    public void setHeightt(Integer heightt) {
        Heightt = heightt;
    }

    public Integer getWeightt() {
        return Weightt;
    }

    public void setWeightt(Integer weightt) {
        Weightt = weightt;
    }

    public Integer getCalorie() {
        return Calorie;
    }

    public void setCalorie(Integer calorie) {
        Calorie = calorie;
    }

    public Integer getStep() {
        return Step;
    }

    public void setStep(Integer step) {
        Step = step;
    }
}
