# Smart-Health-Monitoring-System
The SMART HEALTH MONITORING SYSTEM is an Android application developed using Android Studio which calculates your BMI , provides Step counter , Sleep Suggestion and Water Intake Suggestion .
# Features
BMI Calculator
Step Counter
Sleep Suggestion
Water Suggestion
# Application Uses
Database                  : Firebase
Login and Authentication  : Firebase, Google Sign IN 
Step Counter              : In-built Sensor
# Screenshots:
![Untitled design (19)](https://user-images.githubusercontent.com/47265769/62200093-57c34680-b3a2-11e9-82d3-6f91e81c77bb.png)


